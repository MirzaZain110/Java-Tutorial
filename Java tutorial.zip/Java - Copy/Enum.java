public class Enum {
  enum level{
    LOW,
    MEDIUM,
    q1,
    This_isteststring 
  }  
  public static void main(String[] args)
  {
    level var = level.q1;
    System.out.println("Value : "+ var);
  }
}
