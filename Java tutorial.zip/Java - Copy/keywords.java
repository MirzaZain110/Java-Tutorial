public class keywords {
  final int x = 10;

  public static void main(String[] args) {
    keywords myObj = new keywords();
    // myObj.x = 25; // will generate an error
    System.out.println(myObj.x); 
  }
}
